package android.example.firstapp.Network.Response

import android.example.firstapp.Network.Model.MovieDto
import android.example.firstapp.Network.Model.MovieDto2
import com.google.gson.annotations.SerializedName

class MovieSearchResponse2 (
    @SerializedName("id")
    var id:Int,
    @SerializedName("results")
    var keys : List<MovieDto2>
)