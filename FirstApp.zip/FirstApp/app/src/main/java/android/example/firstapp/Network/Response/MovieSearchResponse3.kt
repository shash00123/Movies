package android.example.firstapp.Network.Response

import android.example.firstapp.Network.Model.backdrops
import com.google.gson.annotations.SerializedName

class MovieSearchResponse3 (
    @SerializedName("backdrops")
    var images:List<backdrops>
)