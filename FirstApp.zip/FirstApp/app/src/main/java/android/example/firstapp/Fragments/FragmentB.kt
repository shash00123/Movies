package android.example.firstapp.Fragments

import android.example.firstapp.R
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.fragment_b.view.*

class FragmentB :Fragment(R.layout.fragment_b){
}