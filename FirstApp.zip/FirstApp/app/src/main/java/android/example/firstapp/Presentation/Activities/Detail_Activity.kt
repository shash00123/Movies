package android.example.firstapp.Presentation.Activities

//import android.example.firstapp.Room.AppDatabse
import android.annotation.SuppressLint
import android.content.Intent
import android.example.firstapp.Domain.Model.Movies
import android.example.firstapp.R
import android.example.firstapp.ViewModel.DetailViewModel
import android.example.firstapp.databinding.DetailActivityBinding
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.squareup.picasso.Picasso
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.*

class Detail_Activity : AppCompatActivity() {
    //    private val Flag = 0
    private val list: List<String> = ArrayList()
    var Titled: String? = null
    var Imaged: String? = null
    var Ratingd: String? = null
    var backimaged: String? = null
    var infod: String? = null
    var movieidd: Int? = null
    private lateinit var binding: DetailActivityBinding
    lateinit var viewmodel: DetailViewModel
    private var flag: Int? = null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DetailActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val intentthatstartedthisactivity: Intent = intent
        val m: Movies? = intentthatstartedthisactivity.getParcelableExtra<Movies>("parcea")
        Titled = m?.Title
        Imaged = m?.Poster
        Ratingd = m?.Vote
        backimaged = m?.BackImage
        infod = m?.Overview
        movieidd = m?.Movieid
        viewmodel = ViewModelProvider(this).get(DetailViewModel::class.java)
        Log.i("@@@@@222", "${viewmodel}")
        val t1 = Toast.makeText(this,
            "Do u really think i could have got movie access lmao",
            Toast.LENGTH_SHORT)
        val t2 = Toast.makeText(this, "Watch trailer and be happy", Toast.LENGTH_SHORT)
        binding.rent.setOnClickListener() {
            t1.show()
            t2.show()
            viewmodel.deletemoviewithtitle(Titled)
        }
        GlobalScope.launch {
            flag=viewmodel.getflagfromtitle(Titled)
            if (flag == 0) {
                binding.watchlistFr.text = "Add to watchlist"
                binding.watchlistFr.setTextColor(resources.getColor(R.color.white))
            } else {
                binding.watchlistFr.text = "Added to watchlist"
                binding.watchlistFr.setTextColor(resources.getColor(R.color.Red))
            }
        }


        binding.TitleFr.setText(Titled)
        val url = "https://image.tmdb.org/t/p/w500" + Imaged
        Picasso.get().load(url).resize(200, 280).into(binding.posterFr)
        binding.ratingFr.text = Ratingd

        val title = "https://image.tmdb.org/t/p/w500" + backimaged
        Picasso.get().load(title).resize(900, 500).into(binding.backgroundImageFr)
        var overview = infod
        var extra: String? = null
        if (overview != null) {
            if (overview.length > 60) {
                extra = overview.substring(60, overview.length)
                overview = overview.substring(0, 60) + "..."
            }
            binding.overviewFr.setText(overview)
        }
        binding.moreFr.setOnClickListener {
            if (binding.moreFr.text.toString().equals("More")) {
                binding.overviewFr.setText(overview?.substring(0, 60) + extra)
                binding.moreFr.text = "Less"
            } else {
                binding.overviewFr.setText(overview)
                binding.moreFr.text = "More"
            }
        }
        binding.trailerFr.setOnClickListener {
            val intentTStartDetailActivity = Intent(this, Trailer_Activity::class.java)
            intentTStartDetailActivity.putExtra(Intent.EXTRA_TEXT, movieidd)
            startActivity(intentTStartDetailActivity)
        }
        binding.imageButton.setOnClickListener {
            val intent = Intent(this, Image_Activity::class.java)
            intent.putExtra("ID", movieidd)
            startActivity(intent)
        }
        binding.watchlistFr.setOnClickListener {
            if (binding.watchlistFr.currentTextColor == resources.getColor(R.color.white)) {
                viewmodel.addmovie(Movies(flag = 1,
                    Movieid = movieidd,
                    Title = Titled,
                    Vote = Ratingd,
                    Overview = infod,
                    BackImage = backimaged,
                    Poster = Imaged))
                binding.watchlistFr.text = "Added To watchlist"
                binding.watchlistFr.setTextColor(resources.getColor(R.color.Red))
            } else {
                viewmodel.deletemoviewithtitle(Titled)
                binding.watchlistFr.text = "Add To watchlist"
                binding.watchlistFr.setTextColor(resources.getColor(R.color.white))
            }
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(R.anim.nothing, R.anim.slide_out)
    }

}