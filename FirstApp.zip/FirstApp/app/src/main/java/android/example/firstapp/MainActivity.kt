package android.example.firstapp

import android.example.firstapp.Fragments.FragmentA
import android.example.firstapp.Fragments.FragmentB
import android.example.firstapp.Fragments.FragmentC
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity() : AppCompatActivity() {

    private lateinit var bn: BottomNavigationView
    private var SelectedFragment: Fragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        val toolbar=findViewById<Toolbar>(R.id.tool)
//        setSupportActionBar(toolbar)
        bn = findViewById<BottomNavigationView>(R.id.bottom_navigation_view)

        bn.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.navigation_home -> {
                    val fragment = FragmentA()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.container_View, fragment, fragment.javaClass.simpleName)
                        .commit()
                    true
                }
                R.id.navigation_explore -> {
                    Log.i("~!@", "CAME!!!!!!!!!!!!!!!!!!")
                    val fragment = FragmentB()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.container_View, fragment, fragment.javaClass.getSimpleName())
                        .commit()
                     true
                }
                R.id.navigation_new -> {
                    val fragment = FragmentC()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.container_View, fragment, fragment.javaClass.getSimpleName())
                        .commit()
                     true
                }
                else -> false
            }
        }
        if (savedInstanceState == null) {
            val fragment = supportFragmentManager.findFragmentByTag(FragmentA::class.java.simpleName) ?: FragmentA()
            Log.i("~!@", "CAME!!!!!!!!!!!!!!!!!!")

            supportFragmentManager.beginTransaction()
                .replace(R.id.container_View, fragment, FragmentA::class.java.simpleName)
                .commit()
        }


    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("detached1","mainactivity")
    }


}